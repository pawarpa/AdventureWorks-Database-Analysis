SELECT COUNT(*) FROM scdtype2.productcosthistoryscd;

select distinct (ProductName) as Distinct_ProductName 
from scdtype2.productcosthistoryscd; 

select ProductID from scdtype2.productcosthistoryscd 
group by ProductID
having count(distinct(StandardCost))>1;

select ProductName,StandardCost,scd_start,scd_version from scdtype2.productcosthistoryscd
where scd_active=1;

SELECT ProductName, StandardCost, scd_start, scd_version
from scdtype2.productcosthistoryscd
where StandardCost = (select max(StandardCost) from scdtype2.productcosthistoryscd);

SELECT ProductName, StandardCost, scd_start, scd_version
from scdtype2.productcosthistoryscd
where StandardCost = (select min(StandardCost) from scdtype2.productcosthistoryscd);

select * from scdtype2.productcosthistoryscd
where ProductName="HL Road Frame - Red, 62";

SELECT COUNT(*) AS Product_Count FROM scdtype2.productcosthistoryscd
WHERE scd_start BETWEEN '2020-01-01 00:00:00.000' AND '2020-12-31 00:00:00.000';





