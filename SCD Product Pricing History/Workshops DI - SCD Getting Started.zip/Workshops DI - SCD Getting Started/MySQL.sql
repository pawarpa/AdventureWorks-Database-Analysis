CREATE TABLE  ProductPriceHistorySCD
(   
    SCD_SK int  not null auto_increment,
	ProductID int NOT NULL,  
	ProductName varchar(50) NOT NULL,
	ListPrice Numeric(19,4) NOT NULL,

	scd_start datetime(3) not null,
	scd_end datetime(3)  null,
	scd_version int not null,
	scd_active int not null,

	DI_JobID varchar(20) null,
	DI_CreateDate datetime default current_timestamp not null,
PRIMARY KEY  (SCD_SK)
);

CREATE TABLE  ProductCostHistorySCD
(   
    SCD_SK int  not null auto_increment,
	ProductID int NOT NULL,   
	ProductName varchar(50) NOT NULL,
	StandardCost Numeric(19,4) NOT NULL,

	scd_start datetime(3) not null,
	scd_end datetime(3)  null,
	scd_version int not null,
	scd_active int not null,

	DI_JobID varchar(20) null,
	DI_CreateDate datetime default current_timestamp not null,
PRIMARY KEY  (SCD_SK)
)
;