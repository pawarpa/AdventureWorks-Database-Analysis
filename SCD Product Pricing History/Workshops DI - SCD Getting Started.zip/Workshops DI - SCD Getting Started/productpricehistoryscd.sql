SELECT COUNT(*) FROM scdtype2.productpricehistoryscd;

select count(ProductName) from scdtype2.productpricehistoryscd where ProductName is not null;

select distinct (ProductName) as Distinct_ProductName 
from scdtype2.productpricehistoryscd; 

select ProductID from scdtype2.productpricehistoryscd 
group by ProductID
having count(distinct(ListPrice))>1;

select ProductName,ListPrice,scd_start,scd_version from scdtype2.productpricehistoryscd
where scd_active=1;

SELECT ProductName, ListPrice, scd_start, scd_version
from scdtype2.productpricehistoryscd
where ListPrice = (select min(ListPrice) from scdtype2.productpricehistoryscd);

select * from scdtype2.productpricehistoryscd
where ProductName="HL Road Frame - Red, 62";
SELECT COUNT(*) AS Product_Count FROM scdtype2.productpricehistoryscd
WHERE scd_start BETWEEN '2020-01-01 00:00:00.000' AND '2020-12-31 00:00:00.000';























